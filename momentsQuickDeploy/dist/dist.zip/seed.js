var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
const prisma = new PrismaClient();
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(`⚡ 开始网站创建管理员...`);
        const adminUsername = 'admin';
        const email = '2900383833@qq.com';
        const existingAdmin = yield prisma.users.findUnique({ where: { username: adminUsername } });
        if (!existingAdmin) {
            const hashedPassword = yield bcrypt.hash('123456', 10);
            yield prisma.users.create({
                data: {
                    username: adminUsername,
                    email: email,
                    password: hashedPassword,
                    status: 1, // 正常
                    role: 1, // 管理员
                    nickname: '超级管理员',
                },
            });
            console.log(`✅ 管理员用户 "${adminUsername}" 已创建.`);
        }
        else {
            console.log(`ℹ️ 管理员用户 "${adminUsername}" 已存在，跳过创建.`);
        }
        console.log('⚡ 开始创建网站信息...');
        const configs = [
            // 网站信息
            {
                k: 'sitename',
                v: '瞬刻'
            },
            {
                k: 'site_url',
                v: ''
            },
            {
                k: 'site_email',
                v: ''
            },
            {
                k: 'site_keywords',
                v: '瞬刻,微信朋友圈,记录瞬间,博客程序,内容发布,博客'
            },
            {
                k: 'site_description',
                v: '瞬刻是一个现代化的社交媒体应用，专注于为用户提供简洁、流畅的内容分享体验。项目采用前后端分离架构，支持文字、图片、视频等多种内容类型的发布和交互。'
            },
            // 网站背景图
            {
                k: 'site_background',
                v: ''
            },
            // 网站LOGO
            {
                k: 'site_logo',
                v: ''
            },
            // 首页用户背景
            {
                k: 'site_header_background',
                v: ''
            },
            {
                k: 'site_avatar',
                v: ''
            },
            {
                k: 'site_brief',
                v: ''
            },
            // 发件邮箱
            {
                k: 'mail_host',
                v: 'smtp.qq.com'
            },
            {
                k: 'mail_port',
                v: '465'
            },
            {
                k: 'mail_secure',
                v: 'true'
            },
            {
                k: 'mail_user',
                v: ''
            },
            {
                k: 'mail_pass',
                v: ''
            },
            {
                k: 'user_auth',
                v: '0'
            },
            {
                k: 'user_captcha',
                v: '0'
            },
            {
                k: 'user_status',
                v: '1'
            },
            {
                k: 'verify_hcaptcha_user',
                v: ''
            },
            {
                k: 'verify_hcaptcha_app',
                v: ''
            },
        ];
        for (const config of configs) {
            yield prisma.config.upsert({
                where: { k: config.k },
                update: {},
                create: config
            });
        }
        console.log(`✅数据填充完成.`);
    });
}
main()
    .catch((e) => { console.error(e); process.exit(1); })
    .finally(() => __awaiter(void 0, void 0, void 0, function* () { yield prisma.$disconnect(); }));
